module.exports = 'may'

