// import jquery from 'jquery'
//
// import moment from 'moment'
//
// import 'moment/locale/zh-cn'
//
// moment.locale('zh-cn')
//
// let r = moment().endOf('day').fromNow()  // 距离现在多少天
// console.log(r);


import React from 'react'

import {render} from 'react-dom'


render(<h1>111111</h1>, window.root)
