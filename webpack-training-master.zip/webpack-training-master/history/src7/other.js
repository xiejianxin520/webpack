import './a'
import './b'

console.log('other.js');


import $ from 'jquery'

console.log($);
