module.exports = 'sdfsdfs'


@log
class A {
    a = 1;
}

let a = new A ()


console.log(a)


function log(target) {
    console.log(target, '23')
}


