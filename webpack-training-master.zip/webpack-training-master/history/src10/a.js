let b = require('./base/b')

module.exports = 'a'+ b

